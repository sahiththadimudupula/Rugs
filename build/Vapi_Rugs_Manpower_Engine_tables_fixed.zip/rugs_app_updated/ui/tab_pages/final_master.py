from __future__ import annotations

import pandas as pd
import streamlit as st

from ui.components import filter_master_df, render_cards, render_filter_bar, render_summary_table
from ui.table_views import render_readonly_table
from ui.table_views import render_readonly_table


def render_final_master_tab() -> None:
    st.markdown("### Final Master Sheet")
    selected_sections, selected_designations = render_filter_bar(st.session_state["master_df"], key_prefix="final_master")
    filtered_df = filter_master_df(st.session_state["master_df"], selected_sections, selected_designations)
    render_cards(filtered_df["Section"].nunique(), filtered_df["BE_Final_Manpower"].sum())
    render_summary_table(filtered_df)
    render_readonly_table(filtered_df, label_column="Section")
