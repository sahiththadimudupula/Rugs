from __future__ import annotations

import streamlit as st

from ui.components import render_cards, render_filtered_section_group
from ui.table_views import render_readonly_table
from ui.table_views import render_readonly_table


def render_cut_and_sew_tab() -> None:
    st.markdown("### Cut & Sew")
    cut_df = st.session_state["master_df"]
    cut_df = cut_df[cut_df["Section"] == "Cut & Sew"]
    render_cards(cut_df["Section"].nunique(), cut_df["BE_Final_Manpower"].sum())
    st.markdown("#### Capacity Table")
    render_readonly_table(st.session_state["capacity_df"], label_column="location")
    st.markdown("#### CS Table")
    render_readonly_table(st.session_state["cs_df"], label_column="Section")
    st.markdown("#### Cut & Sew Manpower")
    st.session_state["master_df"] = render_filtered_section_group(
        "cut_and_sew_section",
        ["Cut & Sew"],
        st.session_state["master_df"],
        show_summary=False,
    )
