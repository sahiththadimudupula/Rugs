from __future__ import annotations

import streamlit as st

from config.constants import PRE_PROCESSING_SECTIONS
from ui.components import render_filtered_section_group


def render_pre_processing_tab() -> None:
    st.markdown("### pre procesing")
    st.session_state["master_df"] = render_filtered_section_group(
        "pre_processing",
        PRE_PROCESSING_SECTIONS,
        st.session_state["master_df"],
    )
