from __future__ import annotations

import streamlit as st

from ui.components import render_cards, render_filtered_section_group
from ui.table_views import render_readonly_table
from ui.tab_pages.common import persist_editor_change
from ui.table_views import render_readonly_table


def render_dyeing_tab() -> None:
    st.markdown("### Dyeing")
    dyeing_df = st.session_state["master_df"]
    dyeing_df = dyeing_df[dyeing_df["Section"] == "Dyeing"]
    render_cards(dyeing_df["Section"].nunique(), dyeing_df["BE_Final_Manpower"].sum())

    st.markdown("#### Planning Inputs")
    input_col1, input_col2 = st.columns(2)
    with input_col1:
        st.markdown("##### EZM / Paddle Input Driver")
        input_driver_df = st.data_editor(
            st.session_state["dyeing_result"]["input_driver_df"],
            key="dyeing_input_driver_editor",
            width="stretch",
            hide_index=True,
            disabled=["Driver"],
        )
        persist_editor_change("dyeing_input_driver_edit_df", input_driver_df, pipeline=True)

    with input_col2:
        st.markdown("##### Jet Dyeing Controls")
        jet_control_df = st.data_editor(
            st.session_state["dyeing_result"]["jet_control_df"],
            key="dyeing_jet_control_editor",
            width="stretch",
            hide_index=True,
            disabled=["Parameter"],
        )
        persist_editor_change("dyeing_jet_control_edit_df", jet_control_df, pipeline=True)

    st.markdown("#### EZM / Paddle Machine Master")
    ezm_master_df = st.data_editor(
        st.session_state["dyeing_result"]["ezm_paddle_master_df"],
        key="dyeing_ezm_paddle_master_editor",
        width="stretch",
        hide_index=True,
        disabled=["Machine_Type"],
    )
    persist_editor_change("dyeing_ezm_paddle_master_edit_df", ezm_master_df, pipeline=True)

    st.markdown("#### EZM / Paddle Output")
    output_col1, output_col2 = st.columns(2)
    with output_col1:
        st.markdown("##### Final Summary")
        render_readonly_table(st.session_state["dyeing_result"]["final_summary_df"], label_column="MC")
        st.markdown("##### Production Summary")
        render_readonly_table(st.session_state["dyeing_result"]["production_summary_df"], label_column="Product")
    with output_col2:
        st.markdown("##### Selected Drylon Machines")
        render_readonly_table(st.session_state["dyeing_result"]["drylon_selected_df"], label_column="MACHINE")
        st.markdown("##### Selected Cotton Machines")
        render_readonly_table(st.session_state["dyeing_result"]["cotton_selected_df"], label_column="MACHINE")

    st.markdown("#### Jet Dyeing Machine Table")
    jet_machine_df = st.data_editor(
        st.session_state["dyeing_result"]["jet_machine_table_df"],
        key="dyeing_jet_machine_editor",
        width="stretch",
        hide_index=True,
    )
    persist_editor_change("dyeing_jet_machine_edit_df", jet_machine_df, pipeline=True)

    st.markdown("#### Jet Dyeing Output")
    option_col1, option_col2 = st.columns(2)
    with option_col1:
        st.markdown("##### Option 1 - Closest With Minimum Machines")
        render_readonly_table(st.session_state["dyeing_result"]["jet_closest_summary_df"], label_column="Metric")
        render_readonly_table(st.session_state["dyeing_result"]["jet_closest_selected_df"], label_column="Sr. No.")
    with option_col2:
        st.markdown("##### Option 2 - New Machine Preference")
        render_readonly_table(st.session_state["dyeing_result"]["jet_new_summary_df"], label_column="Metric")
        render_readonly_table(st.session_state["dyeing_result"]["jet_new_selected_df"], label_column="Sr. No.")

    st.markdown("#### Hydro Table")
    hydro_df = st.data_editor(st.session_state["hydro_df"], key="hydro_editor", width="stretch", hide_index=True)
    persist_editor_change("hydro_edit_df", hydro_df, pipeline=True)
    render_readonly_table(st.session_state["hydro_df"], label_column="Efficiency")

    st.markdown("#### Dyeing Manpower")
    st.session_state["master_df"] = render_filtered_section_group(
        "dyeing_section",
        ["Dyeing"],
        st.session_state["master_df"],
        show_summary=False,
    )
