from __future__ import annotations

import streamlit as st

from ui.components import render_table_cards
from ui.table_views import render_readonly_table
from ui.tab_pages.common import persist_editor_change


def render_ppc_tab() -> None:
    st.markdown("### PPC data")
    current_df = st.session_state["asking_rate_df"].copy()
    editable_mask = current_df["row_type"] == "input"
    render_table_cards(
        "Input Rows",
        int(editable_mask.sum()),
        "Total Asking Rate",
        float(current_df["Asking_Rate_Per_Day"].sum()),
    )

    editor_df = current_df[["Main_Group", "Sub_Group", "Category", "Subcategory", "Asking_Rate_Per_Day", "row_type"]].copy()
    edited_df = st.data_editor(
        editor_df,
        key="packing_editor",
        width="stretch",
        height=520,
        hide_index=True,
        disabled=["Main_Group", "Sub_Group", "Category", "Subcategory", "row_type"],
    )
    persist_editor_change("packing_edit_df", edited_df.drop(columns=["row_type"]), pipeline=True)
    st.markdown("#### PPC Data With Total")
    render_readonly_table(current_df[["Main_Group", "Sub_Group", "Category", "Subcategory", "Asking_Rate_Per_Day"]], label_column="Main_Group")
