from __future__ import annotations

import pandas as pd
import streamlit as st

from core.dataframe_ops import dataframes_different
from core.state import rerun_pipeline
from ui.table_views import render_readonly_table


def persist_editor_change(state_key: str, edited_df: pd.DataFrame, pipeline: bool = True) -> None:
    previous_df = st.session_state.get(state_key)
    normalized_df = edited_df.reset_index(drop=True).copy(deep=True)
    if previous_df is None:
        st.session_state[state_key] = normalized_df
        return
    if dataframes_different(previous_df, normalized_df):
        st.session_state[state_key] = normalized_df
        if pipeline:
            rerun_pipeline()
            st.rerun()


def render_readonly_with_title(title: str, dataframe: pd.DataFrame, label_column: str | None = None) -> None:
    st.markdown(f"#### {title}")
    render_readonly_table(dataframe, label_column=label_column)
