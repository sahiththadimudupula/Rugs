from __future__ import annotations

import streamlit as st

from config.constants import FINAL_SECTION_GROUP
from ui.components import render_filtered_section_group


def render_final_section_tab() -> None:
    st.markdown("### final section")
    st.session_state["master_df"] = render_filtered_section_group(
        "final_section_group",
        FINAL_SECTION_GROUP,
        st.session_state["master_df"],
    )
