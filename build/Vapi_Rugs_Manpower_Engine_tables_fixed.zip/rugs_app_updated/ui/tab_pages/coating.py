from __future__ import annotations

import streamlit as st

from ui.components import render_filtered_section_group, render_table_cards
from ui.tab_pages.common import persist_editor_change
from ui.table_views import render_readonly_table


def render_coating_tab() -> None:
    st.markdown("### Coating")
    coating_df = st.session_state["coating_df"].copy()
    coating_total = float(coating_df[(coating_df["Parameter"] == "Machines Required") & (coating_df["Material"] == "Total")]["Value"].iloc[0])
    coating_drylon = float(coating_df[(coating_df["Parameter"] == "Machines Required") & (coating_df["Material"] == "Drylon")]["Value"].iloc[0])
    render_table_cards("Coating Rows", len(coating_df), "Machines Required Total", coating_total)
    st.markdown("#### Coating Helper Table")
    edited_df = st.data_editor(
        coating_df,
        key="coating_editor",
        width="stretch",
        height=460,
        hide_index=True,
        disabled=["Parameter", "Material"],
    )
    persist_editor_change("coating_edit_df", edited_df, pipeline=True)
    st.caption(f"Machines Required - Drylon: {coating_drylon:,.6f} | Machines Required - Total: {coating_total:,.0f}")
    render_readonly_table(coating_df, label_column="Parameter")
    st.markdown("#### Coating Manpower")
    st.session_state["master_df"] = render_filtered_section_group(
        "coating_section",
        ["Coating"],
        st.session_state["master_df"],
        show_summary=False,
    )
