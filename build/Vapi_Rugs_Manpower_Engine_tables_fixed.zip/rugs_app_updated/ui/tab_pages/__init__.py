from .ppc import render_ppc_tab
from .pre_processing import render_pre_processing_tab
from .coating import render_coating_tab
from .cut_and_sew import render_cut_and_sew_tab
from .dyeing import render_dyeing_tab
from .packing_tqm import render_packintqm_tab
from .final_section import render_final_section_tab
from .final_master import render_final_master_tab

__all__ = [
    'render_ppc_tab',
    'render_pre_processing_tab',
    'render_coating_tab',
    'render_cut_and_sew_tab',
    'render_dyeing_tab',
    'render_packintqm_tab',
    'render_final_section_tab',
    'render_final_master_tab',
]
