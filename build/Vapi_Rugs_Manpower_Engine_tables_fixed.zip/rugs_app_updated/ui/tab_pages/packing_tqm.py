from __future__ import annotations

import streamlit as st

from config.constants import PACKING_TQM_SECTIONS
from ui.components import render_cards, render_filtered_section_group
from ui.table_views import render_readonly_table
from ui.table_views import render_readonly_table


def render_packintqm_tab() -> None:
    st.markdown("### Packin&TQM")
    linked_df = st.session_state["master_df"].copy()
    linked_df = linked_df[linked_df["Section"].isin(PACKING_TQM_SECTIONS)]
    render_cards(
        linked_df["Section"].nunique(),
        linked_df["BE_Scientific_Manpower"].sum(),
        total_label="SUM OF BE_SCIENTIFIC_MANPOWER",
        total_note="Current visible scientific manpower total",
    )

    st.markdown("#### Packin&TQM Helper Source Table")
    render_readonly_table(st.session_state["packing_tqm_source_df"], label_column="Type")
    st.markdown("#### Packin&TQM Draft Manpower Source Table")
    render_readonly_table(st.session_state["packing_tqm_draft_source_df"], label_column="Section")
    st.markdown("#### Calculated Helper Table")
    render_readonly_table(st.session_state["packing_tqm_helper_df"], label_column="Type")
    st.markdown("#### Linked Packin&TQM Manpower")
    st.session_state["master_df"] = render_filtered_section_group(
        "packintqm_section",
        PACKING_TQM_SECTIONS,
        st.session_state["master_df"],
        card_sum_column="BE_Scientific_Manpower",
    )
