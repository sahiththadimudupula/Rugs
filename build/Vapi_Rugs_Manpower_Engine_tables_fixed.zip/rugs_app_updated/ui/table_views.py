from __future__ import annotations

import html

import pandas as pd
import streamlit as st

from core.dataframe_ops import append_total_row, extract_formula_tooltips
from core.formatting import format_display_number


TOTAL_ROW_BACKGROUND = "#f2f7ff"
TABLE_BACKGROUND = "#ffffff"
HEADER_BACKGROUND = "#f7faff"
TEXT_COLOR = "#111111"
HEADER_TEXT_COLOR = "#163b8c"
BORDER_COLOR = "#dce6f7"


def _format_cell_value(cell_value: object) -> str:
    if pd.isna(cell_value):
        return ""
    if isinstance(cell_value, (int, float)):
        return html.escape(format_display_number(cell_value))
    return html.escape(str(cell_value))


def build_html_table(
    dataframe: pd.DataFrame,
    label_column: str | None = None,
    formula_column: str = "Formulas",
) -> str:
    display_df = append_total_row(dataframe, label_column=label_column)
    tooltip_df = extract_formula_tooltips(display_df, formula_column=formula_column)

    header_html = "".join(
        f'<th style="position:sticky;top:0;background:{HEADER_BACKGROUND};color:{HEADER_TEXT_COLOR};'
        f'border:1px solid {BORDER_COLOR};padding:10px 12px;text-align:left;font-weight:700;white-space:nowrap;">'
        f'{html.escape(str(column_name))}</th>'
        for column_name in display_df.columns
    )

    body_rows: list[str] = []
    total_row_index = len(display_df) - 1

    for row_index, row in display_df.iterrows():
        is_total_row = row_index == total_row_index
        row_background = TOTAL_ROW_BACKGROUND if is_total_row else TABLE_BACKGROUND
        row_font_weight = "700" if is_total_row else "500"

        cell_html_parts: list[str] = []
        for column_name in display_df.columns:
            tooltip_text = tooltip_df.at[row_index, column_name] if column_name in tooltip_df.columns else ""
            tooltip_attr = f' title="{html.escape(str(tooltip_text))}"' if str(tooltip_text).strip() else ""
            cell_html_parts.append(
                f'<td{tooltip_attr} style="background:{row_background};color:{TEXT_COLOR};'
                f'border:1px solid {BORDER_COLOR};padding:9px 12px;white-space:nowrap;font-weight:{row_font_weight};">'
                f'{_format_cell_value(row[column_name])}</td>'
            )

        body_rows.append("<tr>" + "".join(cell_html_parts) + "</tr>")

    return f"""
    <div style="width:100%;overflow-x:auto;border:1px solid {BORDER_COLOR};border-radius:14px;background:{TABLE_BACKGROUND};">
        <table style="width:100%;border-collapse:collapse;background:{TABLE_BACKGROUND};font-size:14px;">
            <thead><tr>{header_html}</tr></thead>
            <tbody>{''.join(body_rows)}</tbody>
        </table>
    </div>
    """


def render_readonly_table(
    dataframe: pd.DataFrame,
    label_column: str | None = None,
    formula_column: str = "Formulas",
) -> None:
    st.markdown(
        build_html_table(dataframe, label_column=label_column, formula_column=formula_column),
        unsafe_allow_html=True,
    )
    if formula_column in dataframe.columns:
        st.caption("Hover a numeric cell to see the row formula.")


def render_total_footer(dataframe: pd.DataFrame, label_column: str | None = None) -> None:
    if dataframe.empty:
        return
    total_df = append_total_row(dataframe, label_column=label_column).tail(1).copy()
    st.markdown(build_html_table(total_df, label_column=label_column), unsafe_allow_html=True)
