from __future__ import annotations

import re

import pandas as pd
import streamlit as st

from calculations.master import apply_manual_master_edits
from config.constants import EDITABLE_MASTER_COLUMNS, MASTER_COLUMNS, OPERATOR_TYPE_OPTIONS, COMPACT_SECTION_COLUMNS
from core.dataframe_ops import append_total_row, dataframes_different
from core.formatting import format_display_number
from ui.table_views import render_readonly_table, render_total_footer


SECTION_COUNT_LABEL = "SECTION"
FINAL_MANPOWER_LABEL = "SUM OF BE_FINAL_MANPOWER"
SCIENTIFIC_MANPOWER_LABEL = "SUM OF BE_SCIENTIFIC_MANPOWER"


def build_unique_key(prefix: str, section_name: str) -> str:
    normalized_prefix = re.sub(r"[^a-zA-Z0-9_]+", "_", prefix.strip().lower())
    normalized_section = re.sub(r"[^a-zA-Z0-9_]+", "_", section_name.strip().lower())
    return f"editor_{normalized_prefix}_{normalized_section}"


def render_cards(
    section_count: int,
    total_value: float,
    total_label: str = FINAL_MANPOWER_LABEL,
    total_note: str = "Current visible manpower total",
) -> None:
    card_col1, card_col2 = st.columns(2)

    with card_col1:
        st.markdown(
            f'''
            <div class="metric-card">
                <div class="metric-label">{SECTION_COUNT_LABEL}</div>
                <div class="metric-value">{format_display_number(section_count)}</div>
                <div class="metric-note">Number of visible sections</div>
            </div>
            ''',
            unsafe_allow_html=True,
        )

    with card_col2:
        st.markdown(
            f'''
            <div class="metric-card">
                <div class="metric-label">{total_label}</div>
                <div class="metric-value">{format_display_number(total_value)}</div>
                <div class="metric-note">{total_note}</div>
            </div>
            ''',
            unsafe_allow_html=True,
        )


def render_table_cards(title_left: str, value_left: float | int, title_right: str, value_right: float | int) -> None:
    card_col1, card_col2 = st.columns(2)

    with card_col1:
        st.markdown(
            f'''
            <div class="metric-card">
                <div class="metric-label">{title_left.upper()}</div>
                <div class="metric-value">{format_display_number(value_left)}</div>
            </div>
            ''',
            unsafe_allow_html=True,
        )

    with card_col2:
        st.markdown(
            f'''
            <div class="metric-card">
                <div class="metric-label">{title_right.upper()}</div>
                <div class="metric-value">{format_display_number(value_right)}</div>
            </div>
            ''',
            unsafe_allow_html=True,
        )


def build_summary_table(master_df: pd.DataFrame, sum_column: str = "BE_Final_Manpower") -> pd.DataFrame:
    summary_df = (
        master_df.groupby("Section", as_index=False, sort=False)
        .agg(
            Machine_Count=("Machine_Count", "sum"),
            sum_value=(sum_column, "sum"),
        )
        .rename(columns={"sum_value": f"sum({sum_column})"})
    )
    return summary_df


def render_summary_table(master_df: pd.DataFrame, sum_column: str = "BE_Final_Manpower") -> None:
    summary_df = build_summary_table(master_df, sum_column=sum_column)
    st.markdown("#### Section Summary")
    render_readonly_table(summary_df, label_column="Section")


def render_compact_table(section_df: pd.DataFrame) -> None:
    compact_df = section_df[COMPACT_SECTION_COLUMNS].copy()
    render_readonly_table(compact_df, label_column="Section")


def _coerce_editor_dataframe(edited_df: pd.DataFrame) -> pd.DataFrame:
    coerced_df = edited_df.copy()
    for column_name in MASTER_COLUMNS:
        if column_name not in coerced_df.columns:
            coerced_df[column_name] = ""
    return coerced_df[MASTER_COLUMNS]


def render_editable_section(section_name: str, master_df: pd.DataFrame, key_prefix: str) -> pd.DataFrame:
    section_mask = master_df["Section"] == section_name
    section_df = master_df.loc[section_mask].copy()

    st.markdown('<div class="section-card">', unsafe_allow_html=True)
    st.markdown(f'<div class="section-title">{section_name}</div>', unsafe_allow_html=True)
    render_compact_table(section_df)

    editor_key = build_unique_key(key_prefix, section_name)
    snapshot_key = f"{editor_key}_snapshot"

    with st.expander(f"Expand Section - {section_name}", expanded=False):
        editable_df = section_df[MASTER_COLUMNS].copy()
        editable_df["Operator_Type"] = editable_df["Operator_Type"].replace("", "Direct")

        disabled_columns = [
            column_name for column_name in MASTER_COLUMNS if column_name not in EDITABLE_MASTER_COLUMNS
        ]

        edited_df = st.data_editor(
            editable_df,
            key=editor_key,
            width="stretch",
            num_rows="fixed",
            hide_index=True,
            disabled=disabled_columns,
            column_config={
                "Operator_Type": st.column_config.SelectboxColumn(
                    "Operator_Type",
                    options=OPERATOR_TYPE_OPTIONS,
                    required=False,
                ),
            },
        )

        normalized_edited_df = _coerce_editor_dataframe(edited_df)
        previous_snapshot = st.session_state.get(snapshot_key)

        if dataframes_different(previous_snapshot, normalized_edited_df):
            master_df = apply_manual_master_edits(master_df, normalized_edited_df, section_df)
            st.session_state[snapshot_key] = normalized_edited_df.copy(deep=True)

        render_total_footer(master_df.loc[master_df["Section"] == section_name, MASTER_COLUMNS], label_column="Section")

    st.markdown("</div>", unsafe_allow_html=True)
    return master_df


def render_filtered_section_group(
    tab_name: str,
    sections: list[str],
    master_df: pd.DataFrame,
    show_summary: bool = True,
    card_sum_column: str = "BE_Final_Manpower",
) -> pd.DataFrame:
    visible_df = master_df[master_df["Section"].isin(sections)].copy()

    if visible_df.empty:
        st.info("No rows available for this tab.")
        return master_df

    total_label = FINAL_MANPOWER_LABEL if card_sum_column == "BE_Final_Manpower" else SCIENTIFIC_MANPOWER_LABEL
    render_cards(
        section_count=visible_df["Section"].nunique(),
        total_value=visible_df[card_sum_column].sum(),
        total_label=total_label,
    )

    if show_summary:
        render_summary_table(visible_df, sum_column=card_sum_column)

    for section_name in visible_df["Section"].drop_duplicates().tolist():
        master_df = render_editable_section(section_name, master_df, key_prefix=tab_name)

    return master_df


def render_filter_bar(master_df: pd.DataFrame, key_prefix: str) -> tuple[list[str], list[str]]:
    st.markdown("#### Filters")
    filter_col1, filter_col2 = st.columns(2)

    section_options = master_df["Section"].drop_duplicates().tolist()
    selected_sections = st.session_state.get(f"{key_prefix}_sections", [])

    designation_source_df = master_df
    if selected_sections:
        designation_source_df = master_df[master_df["Section"].isin(selected_sections)]
    designation_options = designation_source_df["Designation"].drop_duplicates().tolist()

    with filter_col1:
        selected_sections = st.multiselect(
            "Section",
            options=section_options,
            default=st.session_state.get(f"{key_prefix}_sections", []),
            key=f"{key_prefix}_sections",
            placeholder="Choose options",
        )

    with filter_col2:
        selected_designations = st.multiselect(
            "Designation",
            options=designation_options,
            default=st.session_state.get(f"{key_prefix}_designations", []),
            key=f"{key_prefix}_designations",
            placeholder="Choose options",
        )

    return selected_sections, selected_designations


def filter_master_df(master_df: pd.DataFrame, sections: list[str], designations: list[str]) -> pd.DataFrame:
    filtered_df = master_df.copy()
    if sections:
        filtered_df = filtered_df[filtered_df["Section"].isin(sections)]
    if designations:
        filtered_df = filtered_df[filtered_df["Designation"].isin(designations)]
    return filtered_df
