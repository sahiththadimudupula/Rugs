from __future__ import annotations

from bisect import bisect_left
from dataclasses import dataclass
from itertools import combinations
import itertools
from collections.abc import Callable

import pandas as pd

from calculations.capacity import ACTUAL_PCS_COLUMN, LOCATION_COLUMN
from core.formatting import round_half_up, to_number

MACHINE_TYPE_EZM = "EZM"
MACHINE_TYPE_PADDLE = "Paddle"
MACHINE_TYPE_OTHER = "Other"

PRODUCT_DRYLON = "DRYLON"
PRODUCT_COTTON = "COTTON"
ALLOWED_MACHINE_TYPES = [MACHINE_TYPE_EZM, MACHINE_TYPE_PADDLE]
DEFAULT_ALLOWED_SHORTAGE = 100
NEW_MACHINE_PREFIX = "new"

JET_OPTION_CLOSEST = "OPTION 1 - CLOSEST WITH MINIMUM MACHINES"
JET_OPTION_NEW_PREFERENCE = "OPTION 2 - NEW MACHINE PREFERENCE WITH MINIMUM MACHINES"

DRIVER_NAME_COLUMN = "Driver"
DRIVER_VALUE_COLUMN = "Value"
JET_CONTROL_NAME_COLUMN = "Parameter"
JET_CONTROL_VALUE_COLUMN = "Value"


@dataclass(frozen=True)
class MachineRecord:
    machine_name: str
    machine_type: str
    production_rate: float


@dataclass(frozen=True)
class HalfCombination:
    total_production: float
    machine_count: int
    selected_indices: tuple[int, ...]


@dataclass(frozen=True)
class ProductTargets:
    drylon: float
    cotton: float


@dataclass
class MachineCombination:
    machine_ids: list[str]
    total_production: int
    machine_count: int
    gap: int
    new_machine_count: int


EZM_PADDLE_MACHINE_COLUMNS = [
    "MACHINE",
    "CAPACITY",
    "CHENILLE",
    "COTTON",
    "DRYLON",
]
JET_MACHINE_COLUMNS = [
    "Sr. No.",
    "Type",
    "Capacity/batch",
    "Loadability",
    "Prod Capacity/batch",
    "RFT",
    "Eff",
    "Cycle Time",
    "Batches/day",
    "Prod/day Kgs",
    "Prod/day Pcs",
    "Buyer",
]


def get_machine_type(machine_name: str) -> str:
    normalized_name = str(machine_name).upper().strip()
    if normalized_name.startswith("EZM"):
        return MACHINE_TYPE_EZM
    if normalized_name.startswith("PD"):
        return MACHINE_TYPE_PADDLE
    return MACHINE_TYPE_OTHER


def build_default_ezm_paddle_master() -> pd.DataFrame:
    machine_rows = [
        {"MACHINE": "EZM-01", "CAPACITY": 120, "CHENILLE": 0.0, "COTTON": 0.0, "DRYLON": 943.03},
        {"MACHINE": "EZM-02", "CAPACITY": 120, "CHENILLE": 0.0, "COTTON": 0.0, "DRYLON": 943.03},
        {"MACHINE": "EZM-03", "CAPACITY": 120, "CHENILLE": 0.0, "COTTON": 0.0, "DRYLON": 943.03},
        {"MACHINE": "EZM-04", "CAPACITY": 120, "CHENILLE": 0.0, "COTTON": 0.0, "DRYLON": 943.03},
        {"MACHINE": "EZM-05", "CAPACITY": 120, "CHENILLE": 0.0, "COTTON": 0.0, "DRYLON": 943.03},
        {"MACHINE": "EZM-06", "CAPACITY": 120, "CHENILLE": 0.0, "COTTON": 0.0, "DRYLON": 943.03},
        {"MACHINE": "EZM-07", "CAPACITY": 220, "CHENILLE": 0.0, "COTTON": 0.0, "DRYLON": 1728.90},
        {"MACHINE": "EZM-08", "CAPACITY": 220, "CHENILLE": 0.0, "COTTON": 0.0, "DRYLON": 1728.90},
        {"MACHINE": "EZM-09", "CAPACITY": 220, "CHENILLE": 0.0, "COTTON": 0.0, "DRYLON": 1728.90},
        {"MACHINE": "EZM-10", "CAPACITY": 220, "CHENILLE": 0.0, "COTTON": 0.0, "DRYLON": 1728.90},
        {"MACHINE": "EZM-11", "CAPACITY": 220, "CHENILLE": 0.0, "COTTON": 0.0, "DRYLON": 1728.90},
        {"MACHINE": "EZM012", "CAPACITY": 220, "CHENILLE": 0.0, "COTTON": 0.0, "DRYLON": 1728.90},
        {"MACHINE": "PD-03", "CAPACITY": 1050, "CHENILLE": 0.0, "COTTON": 0.0, "DRYLON": 6417.87},
        {"MACHINE": "PD-04", "CAPACITY": 1050, "CHENILLE": 0.0, "COTTON": 0.0, "DRYLON": 6417.87},
        {"MACHINE": "PD-07", "CAPACITY": 750, "CHENILLE": 0.0, "COTTON": 0.0, "DRYLON": 4584.20},
        {"MACHINE": "PD-08", "CAPACITY": 750, "CHENILLE": 0.0, "COTTON": 0.0, "DRYLON": 4584.20},
        {"MACHINE": "PD-09", "CAPACITY": 500, "CHENILLE": 0.0, "COTTON": 0.0, "DRYLON": 3056.13},
        {"MACHINE": "EZM-12", "CAPACITY": 220, "CHENILLE": 0.0, "COTTON": 441.94, "DRYLON": 0.0},
        {"MACHINE": "EZM-13", "CAPACITY": 220, "CHENILLE": 0.0, "COTTON": 441.94, "DRYLON": 0.0},
        {"MACHINE": "EZM-14", "CAPACITY": 220, "CHENILLE": 0.0, "COTTON": 441.94, "DRYLON": 0.0},
        {"MACHINE": "EZM-15", "CAPACITY": 220, "CHENILLE": 0.0, "COTTON": 441.94, "DRYLON": 0.0},
        {"MACHINE": "PD-01", "CAPACITY": 1050, "CHENILLE": 0.0, "COTTON": 1792.85, "DRYLON": 0.0},
        {"MACHINE": "PD-02", "CAPACITY": 1050, "CHENILLE": 0.0, "COTTON": 1792.85, "DRYLON": 0.0},
        {"MACHINE": "PD-05", "CAPACITY": 1050, "CHENILLE": 0.0, "COTTON": 1792.85, "DRYLON": 0.0},
        {"MACHINE": "PD-06", "CAPACITY": 1050, "CHENILLE": 0.0, "COTTON": 1792.85, "DRYLON": 0.0},
        {"MACHINE": "PD-10", "CAPACITY": 300, "CHENILLE": 0.0, "COTTON": 512.24, "DRYLON": 0.0},
        {"MACHINE": "PD-11", "CAPACITY": 300, "CHENILLE": 0.0, "COTTON": 512.24, "DRYLON": 0.0},
        {"MACHINE": "PD-12", "CAPACITY": 1050, "CHENILLE": 0.0, "COTTON": 1792.85, "DRYLON": 0.0},
        {"MACHINE": "PD-13", "CAPACITY": 1050, "CHENILLE": 0.0, "COTTON": 1792.85, "DRYLON": 0.0},
        {"MACHINE": "PD-14", "CAPACITY": 1050, "CHENILLE": 0.0, "COTTON": 1792.85, "DRYLON": 0.0},
        {"MACHINE": "PD-15", "CAPACITY": 1050, "CHENILLE": 0.0, "COTTON": 1792.85, "DRYLON": 0.0},
        {"MACHINE": "PD-16", "CAPACITY": 1050, "CHENILLE": 0.0, "COTTON": 1792.85, "DRYLON": 0.0},
        {"MACHINE": "PD-17", "CAPACITY": 1050, "CHENILLE": 0.0, "COTTON": 1792.85, "DRYLON": 0.0},
    ]
    machine_master = pd.DataFrame(machine_rows, columns=EZM_PADDLE_MACHINE_COLUMNS)
    machine_master["Machine_Type"] = machine_master["MACHINE"].apply(get_machine_type)
    return machine_master


def build_default_jet_machine_table() -> pd.DataFrame:
    machine_rows = [
        ["1", "Prod", 300, "65%", 195, "97%", "90%", 4.8, 5.00, 851, 2837, "Walmart"],
        ["2", "Prod", 300, "65%", 195, "97%", "90%", 4.8, 5.00, 851, 2837, "Walmart"],
        ["3", "Prod", 300, "65%", 195, "97%", "90%", 4.8, 5.00, 851, 2837, "Walmart"],
        ["4", "Prod", 300, "65%", 195, "97%", "90%", 4.8, 5.00, 851, 2837, "Walmart"],
        ["5A", "Prod", 150, "65%", 98, "97%", "90%", 4.8, 5.00, 426, 1419, "Walmart"],
        ["5B", "Prod", 150, "85%", 128, "100%", "90%", 6.0, 4.00, 459, 1530, "Target"],
        ["6", "Prod", 300, "85%", 255, "97%", "90%", 6.0, 4.00, 890, 1619, "Target"],
        ["7", "Prod", 405, "85%", 344, "97%", "90%", 6.0, 4.00, 1202, 2186, "Target"],
        ["8", "Prod", 600, "85%", 510, "97%", "90%", 4.8, 5.00, 2226, 4048, "Others"],
        ["new 1", "Prod", 300, "85%", 255, "100%", "90%", 4.5, 5.33, 1224, 2720, "ikea"],
        ["new 2A", "Prod", 300, "85%", 255, "97%", "90%", 4.5, 5.33, 1187, 2159, "ikea"],
        ["new 2B", "Prod", 600, "85%", 510, "97%", "90%", 6.0, 4.00, 1781, 3238, "Target"],
        ["new 2C", "Prod", 600, "85%", 510, "97%", "90%", 6.0, 4.00, 1781, 3238, "Target"],
        ["new 2D", "Prod", 600, "85%", 510, "97%", "90%", 6.0, 4.00, 1781, 3238, "Target"],
    ]
    return pd.DataFrame(machine_rows, columns=JET_MACHINE_COLUMNS)


def build_default_input_driver_table(asking_rate_table: pd.DataFrame, capacity_table: pd.DataFrame) -> pd.DataFrame:
    drylon_target = get_asking_value(asking_rate_table, "Processing", "", "Process", "Drylon Washing")
    cotton_target = get_capacity_pcs(capacity_table, "Cotton-M/C Tufting") + get_capacity_pcs(capacity_table, "Cotton-Table Tufting")
    jet_requirement = round_half_up(get_capacity_pcs(capacity_table, "Chenille") * 1.05, 0)
    return pd.DataFrame(
        {
            DRIVER_NAME_COLUMN: ["Drylon Target", "Cotton Target", "Jet Requirement"],
            DRIVER_VALUE_COLUMN: [drylon_target, cotton_target, jet_requirement],
        }
    )


def build_default_jet_control_table(input_driver_table: pd.DataFrame) -> pd.DataFrame:
    jet_requirement = get_driver_value(input_driver_table, "Jet Requirement")
    return pd.DataFrame(
        {
            JET_CONTROL_NAME_COLUMN: ["Requirement", "Allowed Shortage"],
            JET_CONTROL_VALUE_COLUMN: [jet_requirement, DEFAULT_ALLOWED_SHORTAGE],
        }
    )


def prepare_ezm_paddle_master(machine_table: pd.DataFrame | None) -> pd.DataFrame:
    table = build_default_ezm_paddle_master() if machine_table is None else machine_table.copy()
    for column_name in EZM_PADDLE_MACHINE_COLUMNS:
        if column_name not in table.columns:
            table[column_name] = 0.0 if column_name != "MACHINE" else ""
    table = table[EZM_PADDLE_MACHINE_COLUMNS].copy()
    table["MACHINE"] = table["MACHINE"].astype(str)
    for column_name in ["CAPACITY", "CHENILLE", "COTTON", "DRYLON"]:
        table[column_name] = table[column_name].apply(to_number)
    table["Machine_Type"] = table["MACHINE"].apply(get_machine_type)
    return table


def prepare_jet_machine_table(machine_table: pd.DataFrame | None) -> pd.DataFrame:
    table = build_default_jet_machine_table() if machine_table is None else machine_table.copy()
    for column_name in JET_MACHINE_COLUMNS:
        if column_name not in table.columns:
            table[column_name] = "" if column_name in {"Sr. No.", "Type", "Loadability", "RFT", "Eff", "Buyer"} else 0.0
    table = table[JET_MACHINE_COLUMNS].copy()
    for column_name in ["Capacity/batch", "Prod Capacity/batch", "Cycle Time", "Batches/day", "Prod/day Kgs", "Prod/day Pcs"]:
        table[column_name] = table[column_name].apply(to_number)
    table["Sr. No."] = table["Sr. No."].astype(str)
    return table


def prepare_input_driver_table(
    asking_rate_table: pd.DataFrame,
    capacity_table: pd.DataFrame,
    edited_driver_table: pd.DataFrame | None,
) -> pd.DataFrame:
    base_table = build_default_input_driver_table(asking_rate_table, capacity_table)
    if edited_driver_table is None:
        return base_table
    edited = edited_driver_table.copy()
    for column_name in [DRIVER_NAME_COLUMN, DRIVER_VALUE_COLUMN]:
        if column_name not in edited.columns:
            return base_table
    edited[DRIVER_NAME_COLUMN] = edited[DRIVER_NAME_COLUMN].astype(str)
    edited[DRIVER_VALUE_COLUMN] = edited[DRIVER_VALUE_COLUMN].apply(to_number)
    return edited[[DRIVER_NAME_COLUMN, DRIVER_VALUE_COLUMN]].copy()


def prepare_jet_control_table(
    input_driver_table: pd.DataFrame,
    edited_control_table: pd.DataFrame | None,
) -> pd.DataFrame:
    base_table = build_default_jet_control_table(input_driver_table)
    if edited_control_table is None:
        return base_table
    edited = edited_control_table.copy()
    for column_name in [JET_CONTROL_NAME_COLUMN, JET_CONTROL_VALUE_COLUMN]:
        if column_name not in edited.columns:
            return base_table
    edited[JET_CONTROL_NAME_COLUMN] = edited[JET_CONTROL_NAME_COLUMN].astype(str)
    edited[JET_CONTROL_VALUE_COLUMN] = edited[JET_CONTROL_VALUE_COLUMN].apply(to_number)
    return edited[[JET_CONTROL_NAME_COLUMN, JET_CONTROL_VALUE_COLUMN]].copy()


def get_driver_value(driver_table: pd.DataFrame, driver_name: str) -> float:
    row = driver_table[driver_table[DRIVER_NAME_COLUMN] == driver_name]
    if row.empty:
        return 0.0
    return to_number(row.iloc[0][DRIVER_VALUE_COLUMN])


def get_control_value(control_table: pd.DataFrame, parameter_name: str) -> float:
    row = control_table[control_table[JET_CONTROL_NAME_COLUMN] == parameter_name]
    if row.empty:
        return 0.0
    return to_number(row.iloc[0][JET_CONTROL_VALUE_COLUMN])


def get_capacity_pcs(capacity_table: pd.DataFrame, location_name: str) -> float:
    row = capacity_table[capacity_table[LOCATION_COLUMN] == location_name]
    if row.empty:
        return 0.0
    return to_number(row.iloc[0][ACTUAL_PCS_COLUMN])


def get_asking_value(asking_rate_table: pd.DataFrame, main_group: str, sub_group: str, category: str, subcategory: str) -> float:
    mask = (
        (asking_rate_table["Main_Group"].astype(str).str.strip() == main_group)
        & (asking_rate_table["Sub_Group"].fillna("").astype(str).str.strip() == sub_group)
        & (asking_rate_table["Category"].astype(str).str.strip() == category)
        & (asking_rate_table["Subcategory"].astype(str).str.strip() == subcategory)
    )
    row = asking_rate_table[mask]
    if row.empty:
        return 0.0
    return to_number(row.iloc[0]["Asking_Rate_Per_Day"])


def filter_product_machines(machine_master: pd.DataFrame, product_column: str) -> list[MachineRecord]:
    product_rows = machine_master[
        (machine_master[product_column] > 0)
        & (machine_master["Machine_Type"].isin(ALLOWED_MACHINE_TYPES))
    ].copy()
    return [
        MachineRecord(
            machine_name=row["MACHINE"],
            machine_type=row["Machine_Type"],
            production_rate=float(row[product_column]),
        )
        for _, row in product_rows.iterrows()
    ]


def generate_half_combinations(machine_records: list[MachineRecord]) -> list[HalfCombination]:
    half_combinations: list[HalfCombination] = []
    record_indices = list(range(len(machine_records)))
    for selection_size in range(len(machine_records) + 1):
        for selected_indices in combinations(record_indices, selection_size):
            total_production = sum(machine_records[index].production_rate for index in selected_indices)
            half_combinations.append(HalfCombination(total_production, selection_size, selected_indices))
    return half_combinations


def split_machine_records(machine_records: list[MachineRecord]) -> tuple[list[MachineRecord], list[MachineRecord]]:
    split_position = len(machine_records) // 2
    return machine_records[:split_position], machine_records[split_position:]


def build_second_half_lookup(second_half_combinations: list[HalfCombination]) -> tuple[list[float], dict[float, HalfCombination]]:
    best_combination_by_total: dict[float, HalfCombination] = {}
    for combination_item in second_half_combinations:
        current_best = best_combination_by_total.get(combination_item.total_production)
        if current_best is None or combination_item.machine_count < current_best.machine_count:
            best_combination_by_total[combination_item.total_production] = combination_item
    sorted_totals = sorted(best_combination_by_total.keys())
    return sorted_totals, best_combination_by_total


def choose_better_solution(current_best, candidate_machine_count: int, candidate_total_production: float, target_production: float, candidate_indices: tuple[int, ...]):
    candidate_excess = candidate_total_production - target_production
    candidate_score = (
        candidate_machine_count,
        round(candidate_excess, 6),
        -round(candidate_total_production, 6),
        candidate_indices,
    )
    if current_best is None or candidate_score < current_best:
        return candidate_score
    return current_best


def find_minimum_machine_solution(machine_records: list[MachineRecord], target_production: float) -> tuple[list[str], float]:
    if not machine_records:
        return [], 0.0
    first_half_records, second_half_records = split_machine_records(machine_records)
    first_half_combinations = generate_half_combinations(first_half_records)
    second_half_combinations = generate_half_combinations(second_half_records)
    second_half_totals, second_half_lookup = build_second_half_lookup(second_half_combinations)

    best_solution = None
    best_selected_indices: tuple[int, ...] = ()
    for first_half_combination in first_half_combinations:
        required_second_half = target_production - first_half_combination.total_production
        matched_position = bisect_left(second_half_totals, required_second_half)
        if matched_position >= len(second_half_totals):
            continue
        second_half_total = second_half_totals[matched_position]
        second_half_combination = second_half_lookup[second_half_total]
        combined_total = first_half_combination.total_production + second_half_combination.total_production
        combined_machine_count = first_half_combination.machine_count + second_half_combination.machine_count
        combined_indices = first_half_combination.selected_indices + tuple(
            len(first_half_records) + index for index in second_half_combination.selected_indices
        )
        updated_solution = choose_better_solution(
            best_solution,
            combined_machine_count,
            combined_total,
            target_production,
            combined_indices,
        )
        if updated_solution != best_solution:
            best_solution = updated_solution
            best_selected_indices = combined_indices

    if best_solution is None:
        return [], 0.0
    selected_machine_names = [machine_records[index].machine_name for index in best_selected_indices]
    achieved_production = best_solution[2]
    return selected_machine_names, achieved_production


def build_selected_machine_dataframe(machine_master: pd.DataFrame, selected_machine_names: list[str], product_column: str) -> pd.DataFrame:
    selected_machine_set = set(selected_machine_names)
    selected_machine_table = machine_master[machine_master["MACHINE"].isin(selected_machine_set)].copy()
    if selected_machine_table.empty:
        return pd.DataFrame(columns=["MACHINE", "Machine_Type", product_column, "Machine_count", "Selected_Production"])
    selected_machine_table["Machine_count"] = 1
    selected_machine_table["Selected_Production"] = selected_machine_table[product_column]
    return selected_machine_table[["MACHINE", "Machine_Type", product_column, "Machine_count", "Selected_Production"]].sort_values(["Machine_Type", "MACHINE"]).reset_index(drop=True)


def count_selected_machines_by_type(selected_machine_table: pd.DataFrame) -> pd.Series:
    if selected_machine_table.empty:
        return pd.Series([0, 0], index=ALLOWED_MACHINE_TYPES, dtype=int)
    return (
        selected_machine_table.groupby("Machine_Type")["Machine_count"]
        .sum()
        .reindex(ALLOWED_MACHINE_TYPES, fill_value=0)
        .astype(int)
    )


def count_available_machines_by_type(machine_master: pd.DataFrame) -> pd.Series:
    return (
        machine_master[machine_master["Machine_Type"].isin(ALLOWED_MACHINE_TYPES)]
        .groupby("Machine_Type")["MACHINE"]
        .count()
        .reindex(ALLOWED_MACHINE_TYPES, fill_value=0)
        .astype(int)
    )


def build_final_summary_table(available_machine_count: pd.Series, drylon_machine_count: pd.Series, cotton_machine_count: pd.Series) -> pd.DataFrame:
    total_machine_count = drylon_machine_count + cotton_machine_count
    short_or_excess_machine_count = available_machine_count - total_machine_count
    return pd.DataFrame(
        {
            "MC": ["Drylon", "Cotton", "Total", "Avail", "Short/Excess"],
            MACHINE_TYPE_EZM: [
                int(drylon_machine_count[MACHINE_TYPE_EZM]),
                int(cotton_machine_count[MACHINE_TYPE_EZM]),
                int(total_machine_count[MACHINE_TYPE_EZM]),
                int(available_machine_count[MACHINE_TYPE_EZM]),
                int(short_or_excess_machine_count[MACHINE_TYPE_EZM]),
            ],
            MACHINE_TYPE_PADDLE: [
                int(drylon_machine_count[MACHINE_TYPE_PADDLE]),
                int(cotton_machine_count[MACHINE_TYPE_PADDLE]),
                int(total_machine_count[MACHINE_TYPE_PADDLE]),
                int(available_machine_count[MACHINE_TYPE_PADDLE]),
                int(short_or_excess_machine_count[MACHINE_TYPE_PADDLE]),
            ],
        }
    )


def build_production_summary_table(targets: ProductTargets, achieved_drylon_production: float, achieved_cotton_production: float) -> pd.DataFrame:
    return pd.DataFrame(
        {
            "Product": ["Drylon", "Cotton"],
            "Target_Production": [targets.drylon, targets.cotton],
            "Achieved_Production": [achieved_drylon_production, achieved_cotton_production],
            "Excess_or_Short": [
                round(achieved_drylon_production - targets.drylon, 4),
                round(achieved_cotton_production - targets.cotton, 4),
            ],
        }
    )


def optimize_product_selection(machine_master: pd.DataFrame, product_column: str, target_production: float) -> tuple[pd.DataFrame, float]:
    product_machine_records = filter_product_machines(machine_master, product_column)
    selected_machine_names, achieved_production = find_minimum_machine_solution(product_machine_records, target_production)
    selected_machine_table = build_selected_machine_dataframe(machine_master, selected_machine_names, product_column)
    return selected_machine_table, achieved_production


def is_valid_combination(total_production: int, requirement: int, allowed_shortage: int) -> bool:
    minimum_required_production = requirement - allowed_shortage
    return total_production >= minimum_required_production


def is_new_machine(machine_id: str) -> bool:
    return machine_id.strip().lower().startswith(NEW_MACHINE_PREFIX)


def build_result(machine_group, requirement: int) -> MachineCombination:
    machine_ids = [machine_id for machine_id, _ in machine_group]
    total_production = sum(production for _, production in machine_group)
    new_machine_count = sum(is_new_machine(machine_id) for machine_id in machine_ids)
    return MachineCombination(
        machine_ids=machine_ids,
        total_production=total_production,
        machine_count=len(machine_ids),
        gap=total_production - requirement,
        new_machine_count=new_machine_count,
    )


SelectionRule = Callable[[MachineCombination | None, MachineCombination], MachineCombination]


def choose_closest_combination(current_best: MachineCombination | None, candidate: MachineCombination) -> MachineCombination:
    if current_best is None:
        return candidate
    current_gap = abs(current_best.gap)
    candidate_gap = abs(candidate.gap)
    if candidate_gap < current_gap:
        return candidate
    if candidate_gap > current_gap:
        return current_best
    if candidate.total_production > current_best.total_production:
        return candidate
    return current_best


def choose_new_machine_preference(current_best: MachineCombination | None, candidate: MachineCombination) -> MachineCombination:
    if current_best is None:
        return candidate
    if candidate.new_machine_count > current_best.new_machine_count:
        return candidate
    if candidate.new_machine_count < current_best.new_machine_count:
        return current_best
    return choose_closest_combination(current_best, candidate)


def find_best_combination(machine_table: pd.DataFrame, requirement: int, allowed_shortage: int, selection_rule: SelectionRule) -> MachineCombination | None:
    machine_options = list(zip(machine_table["Sr. No."], machine_table["Prod/day Pcs"]))
    for machine_count in range(1, len(machine_options) + 1):
        best_for_machine_count = None
        for machine_group in itertools.combinations(machine_options, machine_count):
            total_production = sum(production for _, production in machine_group)
            if not is_valid_combination(total_production, requirement, allowed_shortage):
                continue
            candidate = build_result(machine_group, requirement)
            best_for_machine_count = selection_rule(best_for_machine_count, candidate)
        if best_for_machine_count is not None:
            return best_for_machine_count
    return None


def build_selected_jet_machine_table(machine_table: pd.DataFrame, result: MachineCombination | None) -> pd.DataFrame:
    if result is None:
        return pd.DataFrame(columns=machine_table.columns)
    selected_table = machine_table[machine_table["Sr. No."].isin(result.machine_ids)].copy()
    selected_table["selection_order"] = pd.Categorical(selected_table["Sr. No."], categories=result.machine_ids, ordered=True)
    return selected_table.sort_values("selection_order").drop(columns="selection_order").reset_index(drop=True)


def build_combination_summary(option_name: str, requirement: float, allowed_shortage: float, result: MachineCombination | None) -> pd.DataFrame:
    if result is None:
        return pd.DataFrame(
            {
                "Option": [option_name],
                "Requirement": [requirement],
                "Allowed Shortage": [allowed_shortage],
                "Machines Used": [0],
                "New Machines": [0],
                "Total Production": [0],
                "Gap": [0],
            }
        )
    return pd.DataFrame(
        {
            "Option": [option_name],
            "Requirement": [requirement],
            "Allowed Shortage": [allowed_shortage],
            "Machines Used": [result.machine_count],
            "New Machines": [result.new_machine_count],
            "Total Production": [result.total_production],
            "Gap": [result.gap],
        }
    )


def recalculate_dyeing_tables(
    asking_rate_table: pd.DataFrame,
    capacity_table: pd.DataFrame,
    edited_input_driver_df: pd.DataFrame | None = None,
    edited_ezm_paddle_machine_df: pd.DataFrame | None = None,
    edited_jet_control_df: pd.DataFrame | None = None,
    edited_jet_machine_df: pd.DataFrame | None = None,
) -> dict[str, object]:
    input_driver_df = prepare_input_driver_table(asking_rate_table, capacity_table, edited_input_driver_df)
    ezm_paddle_master_df = prepare_ezm_paddle_master(edited_ezm_paddle_machine_df)
    jet_control_df = prepare_jet_control_table(input_driver_df, edited_jet_control_df)
    jet_machine_table_df = prepare_jet_machine_table(edited_jet_machine_df)

    targets = ProductTargets(
        drylon=get_driver_value(input_driver_df, "Drylon Target"),
        cotton=get_driver_value(input_driver_df, "Cotton Target"),
    )

    drylon_selected_df, achieved_drylon_production = optimize_product_selection(
        ezm_paddle_master_df,
        PRODUCT_DRYLON,
        targets.drylon,
    )
    cotton_selected_df, achieved_cotton_production = optimize_product_selection(
        ezm_paddle_master_df,
        PRODUCT_COTTON,
        targets.cotton,
    )

    available_machine_count = count_available_machines_by_type(ezm_paddle_master_df)
    drylon_machine_count = count_selected_machines_by_type(drylon_selected_df)
    cotton_machine_count = count_selected_machines_by_type(cotton_selected_df)
    final_summary_df = build_final_summary_table(available_machine_count, drylon_machine_count, cotton_machine_count)
    production_summary_df = build_production_summary_table(targets, achieved_drylon_production, achieved_cotton_production)

    ezm_count = int(drylon_machine_count[MACHINE_TYPE_EZM] + cotton_machine_count[MACHINE_TYPE_EZM])
    paddle_count = int(drylon_machine_count[MACHINE_TYPE_PADDLE] + cotton_machine_count[MACHINE_TYPE_PADDLE])

    jet_requirement = int(round_half_up(get_control_value(jet_control_df, "Requirement"), 0))
    allowed_shortage = int(round_half_up(get_control_value(jet_control_df, "Allowed Shortage"), 0))

    closest_result = find_best_combination(jet_machine_table_df, jet_requirement, allowed_shortage, choose_closest_combination)
    new_machine_result = find_best_combination(jet_machine_table_df, jet_requirement, allowed_shortage, choose_new_machine_preference)

    closest_summary_df = build_combination_summary(JET_OPTION_CLOSEST, jet_requirement, allowed_shortage, closest_result)
    closest_selected_df = build_selected_jet_machine_table(jet_machine_table_df, closest_result)
    new_summary_df = build_combination_summary(JET_OPTION_NEW_PREFERENCE, jet_requirement, allowed_shortage, new_machine_result)
    new_selected_df = build_selected_jet_machine_table(jet_machine_table_df, new_machine_result)

    jet_count = 0 if closest_result is None else closest_result.machine_count
    output_summary_df = pd.DataFrame(
        {
            "Metric": ["EZM Count", "Paddle Count", "Jet Machine Count", "Drylon Achieved", "Cotton Achieved"],
            "Value": [ezm_count, paddle_count, jet_count, achieved_drylon_production, achieved_cotton_production],
        }
    )
    summary_df = pd.concat(
        [
            input_driver_df.rename(columns={DRIVER_NAME_COLUMN: "Metric", DRIVER_VALUE_COLUMN: "Value"}),
            output_summary_df,
        ],
        ignore_index=True,
    )

    return {
        "summary_df": summary_df,
        "input_driver_df": input_driver_df,
        "ezm_paddle_master_df": ezm_paddle_master_df,
        "final_summary_df": final_summary_df,
        "production_summary_df": production_summary_df,
        "drylon_selected_df": drylon_selected_df,
        "cotton_selected_df": cotton_selected_df,
        "jet_control_df": jet_control_df,
        "jet_machine_table_df": jet_machine_table_df,
        "jet_closest_summary_df": closest_summary_df,
        "jet_closest_selected_df": closest_selected_df,
        "jet_new_summary_df": new_summary_df,
        "jet_new_selected_df": new_selected_df,
        "output_summary_df": output_summary_df,
        "ezm_count": ezm_count,
        "paddle_count": paddle_count,
        "jet_count": jet_count,
        "drylon_achieved": achieved_drylon_production,
        "cotton_achieved": achieved_cotton_production,
    }
