from __future__ import annotations

import pandas as pd

from calculations.capacity import ACTUAL_PCS_COLUMN, LOCATION_COLUMN
from core.formatting import clean_text, to_number

HELPER_COLUMNS = [
    "Type",
    "Line",
    "Req/Day",
    "Production Capacity",
    "Reqd. Lines",
    "TQM Capacity",
    "TQM",
    "Notes",
]

DRAFT_COLUMNS = [
    "Location",
    "Business",
    "Section",
    "Sr_No",
    "Dept_Machine_Name",
    "Designation",
    "Machine_Count",
    "Workload",
    "Formulas",
    "BE_Scientific_Manpower",
    "Operator_Type",
    "Contractors",
    "Company_Associate",
    "BE_Final_Manpower",
    "N_shift",
    "General_Shift",
    "Shift_A",
    "Shift_B",
    "Shift_C",
    "Reliever",
    "Remarks",
]


def get_capacity_pcs(capacity_table: pd.DataFrame, location_name: str) -> float:
    row = capacity_table[capacity_table[LOCATION_COLUMN] == location_name]
    if row.empty:
        return 0.0
    return to_number(row.iloc[0][ACTUAL_PCS_COLUMN])


def get_asking_value(asking_rate_table: pd.DataFrame, main_group: str, sub_group: str, category: str, subcategory: str) -> float:
    mask = (
        (asking_rate_table["Main_Group"].astype(str).str.strip() == main_group)
        & (asking_rate_table["Sub_Group"].fillna("").astype(str).str.strip() == sub_group)
        & (asking_rate_table["Category"].astype(str).str.strip() == category)
        & (asking_rate_table["Subcategory"].astype(str).str.strip() == subcategory)
    )
    row = asking_rate_table[mask]
    if row.empty:
        return 0.0
    return to_number(row.iloc[0]["Asking_Rate_Per_Day"])


def build_packing_tqm_helper(capacity_table: pd.DataFrame, asking_rate_table: pd.DataFrame) -> pd.DataFrame:
    smart_line_req_day = get_capacity_pcs(capacity_table, "Bath Rugs (Wash)") + get_capacity_pcs(capacity_table, "Bath Rugs (Non- Wash with Tumble)")
    ina_req_day = get_capacity_pcs(capacity_table, "Bath Rugs (Non- Wash with Tumble)") + get_capacity_pcs(capacity_table, "Total")
    chenille_req_day = get_capacity_pcs(capacity_table, "Chenille")
    cotton_req_day = get_asking_value(asking_rate_table, "Processing", "", "Process", "Cotton dyeing")

    helper_rows = [
        {
            "Type": "Drylon",
            "Line": "Smart Line",
            "Req/Day": smart_line_req_day,
            "Production Capacity": 4500.0,
            "Reqd. Lines": smart_line_req_day / 4500.0 / 3.0,
            "TQM Capacity": 1200.0,
            "TQM": 4500.0 / 1200.0,
            "Notes": "Reqd. Lines = Req/Day / Production Capacity / 3",
        },
        {
            "Type": "Drylon",
            "Line": "INA",
            "Req/Day": ina_req_day,
            "Production Capacity": 4500.0,
            "Reqd. Lines": ina_req_day / 4500.0 / 3.0,
            "TQM Capacity": 1200.0,
            "TQM": 4500.0 / 1200.0,
            "Notes": "Loading = always 1 person per line per shift",
        },
        {
            "Type": "Chenille",
            "Line": "Manual (Chenille)",
            "Req/Day": chenille_req_day,
            "Production Capacity": 1500.0,
            "Reqd. Lines": chenille_req_day / 1500.0 / 3.0,
            "TQM Capacity": 1500.0,
            "TQM": 1500.0 / 1500.0,
            "Notes": "Smart Line capped at 2 lines; balance moves to INA",
        },
        {
            "Type": "Cotton",
            "Line": "Manual (Cotton)",
            "Req/Day": cotton_req_day,
            "Production Capacity": 1500.0,
            "Reqd. Lines": cotton_req_day / 1500.0 / 3.0,
            "TQM Capacity": 800.0,
            "TQM": 1500.0 / 800.0,
            "Notes": "TQM = Production Capacity / TQM Capacity",
        },
    ]
    return pd.DataFrame(helper_rows, columns=HELPER_COLUMNS)


def _normalize_header_list(header_values: list[object]) -> list[str]:
    return [clean_text(value) for value in header_values]


def split_packing_tqm_tables(raw_sheet_df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    helper_source_df = pd.DataFrame(columns=HELPER_COLUMNS)
    draft_source_df = pd.DataFrame(columns=DRAFT_COLUMNS)

    if raw_sheet_df.empty:
        return helper_source_df, draft_source_df

    helper_header_row = 1
    helper_data_end_row = 5
    helper_block = raw_sheet_df.iloc[helper_header_row:helper_data_end_row + 1, :7].copy()
    helper_columns = _normalize_header_list(helper_block.iloc[0].tolist())
    helper_block.columns = helper_columns
    helper_block = helper_block.iloc[1:].reset_index(drop=True)
    if helper_columns[:7] == HELPER_COLUMNS[:7]:
        helper_block["Notes"] = ""
        helper_source_df = helper_block[HELPER_COLUMNS].copy()
        for numeric_column in ["Req/Day", "Production Capacity", "Reqd. Lines", "TQM Capacity", "TQM"]:
            helper_source_df[numeric_column] = helper_source_df[numeric_column].apply(to_number)

    draft_header_row = 9
    draft_block = raw_sheet_df.iloc[draft_header_row:, : len(DRAFT_COLUMNS)].copy()
    draft_columns = _normalize_header_list(draft_block.iloc[0].tolist())
    draft_columns = ["N_shift" if column_name == "N_shifts" else column_name for column_name in draft_columns]
    draft_block.columns = draft_columns
    draft_block = draft_block.iloc[1:].reset_index(drop=True)
    if draft_columns == DRAFT_COLUMNS:
        draft_source_df = draft_block.copy()
        for numeric_column in [
            "Sr_No",
            "Machine_Count",
            "BE_Scientific_Manpower",
            "Contractors",
            "Company_Associate",
            "BE_Final_Manpower",
            "N_shift",
            "General_Shift",
            "Shift_A",
            "Shift_B",
            "Shift_C",
            "Reliever",
        ]:
            draft_source_df[numeric_column] = draft_source_df[numeric_column].apply(to_number)

    return helper_source_df, draft_source_df
