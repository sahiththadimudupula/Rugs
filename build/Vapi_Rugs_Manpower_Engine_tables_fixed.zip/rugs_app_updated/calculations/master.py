from __future__ import annotations

import math
import re

import pandas as pd

from core.formatting import clean_text, to_number, round_half_up
from config.constants import MASTER_COLUMNS, PACKING_TQM_SECTIONS

SECTION_ALIASES = {
    "Packing  Line MP": ["Packing  Line MP", "Production Line MP"],
    "Packing Support MP": ["Packing Support MP", "Support MP"],
    "TQM Other Support": ["TQM Other Support", "Other Support"],
}

CUSTOM_WORKLOAD_KEYWORDS = {
    "sum of required lines",
    "half of total lines",
    "3 x total required lines",
    "(Chenille Req/Day/3)/600",
    "ROUNDUP(TQM*Reqd.Lines,0) per shift",
    "ROUNDUP(4/3,0) person/shift",
}

COATING_SPECIAL_DESIGNATIONS = {
    "OPERATOR (STITCHING  & Feeding)",
    "OPERATOR (PRE-COAT APPLICATION HEAD)",
    "OPERATOR (MAIN COAT APPLICATION HEAD)",
    "OPERATOR (LATEX KITCHEN)",
}

TEXT_COLUMNS = [
    "Location",
    "Business",
    "Section",
    "Dept_Machine_Name",
    "Designation",
    "Workload",
    "Formulas",
    "Operator_Type",
    "Remarks",
]

NUMERIC_COLUMNS = [
    "Sr_No",
    "Machine_Count",
    "BE_Scientific_Manpower",
    "Contractors",
    "Company_Associate",
    "BE_Final_Manpower",
    "N_shift",
    "General_Shift",
    "Shift_A",
    "Shift_B",
    "Shift_C",
    "Reliever",
]


def get_section_candidates(section_name: str) -> list[str]:
    return SECTION_ALIASES.get(section_name, [section_name])


def format_formula_number(value: float) -> str:
    rounded_value = round(to_number(value), 6)
    if abs(rounded_value - round(rounded_value)) < 1e-9:
        return str(int(round(rounded_value)))
    return f"{rounded_value:.6f}".rstrip("0").rstrip(".")


def prepare_master_table(source_table: pd.DataFrame) -> pd.DataFrame:
    table = source_table.copy()

    for column_name in MASTER_COLUMNS:
        if column_name not in table.columns:
            table[column_name] = ""

    for column_name in TEXT_COLUMNS:
        table[column_name] = table[column_name].apply(clean_text)

    for column_name in NUMERIC_COLUMNS:
        table[column_name] = table[column_name].apply(to_number)

    table["_business_order"] = range(len(table))
    if "_machine_count_overridden" not in table.columns:
        table["_machine_count_overridden"] = False
    table["_machine_count_overridden"] = table["_machine_count_overridden"].fillna(False).astype(bool)
    table["_scientific_ratio"] = table.apply(
        lambda row: 0.0
        if to_number(row["Machine_Count"]) == 0
        else to_number(row["BE_Scientific_Manpower"]) / to_number(row["Machine_Count"]),
        axis=1,
    )
    return table


def clone_master_with_user_edits(
    base_master: pd.DataFrame,
    live_master: pd.DataFrame | None,
) -> pd.DataFrame:
    if live_master is None:
        return base_master.copy()

    updated = base_master.copy()
    editable_columns = [
        "Machine_Count",
        "Operator_Type",
        "Contractors",
        "Company_Associate",
        "BE_Final_Manpower",
        "General_Shift",
        "Shift_A",
        "Shift_B",
        "Shift_C",
        "Reliever",
        "Remarks",
        "_machine_count_overridden",
    ]

    for column_name in editable_columns:
        if column_name in live_master.columns:
            updated[column_name] = live_master[column_name].values

    return updated


def build_row_mask(
    master_table: pd.DataFrame,
    section: str,
    dept_machine_name: str,
    designation: str,
) -> pd.Series:
    return (
        master_table["Section"].isin(get_section_candidates(section))
        & (master_table["Dept_Machine_Name"] == dept_machine_name)
        & (master_table["Designation"] == designation)
    )


def determine_shift_multiplier(workload: str, n_shift: float) -> float:
    normalized_workload = workload.lower()

    if "general shift" in normalized_workload:
        return 1.0
    if "/day" in normalized_workload:
        return 1.0

    shift_match = re.search(r"/\s*([0-9.]+)\s*shift", normalized_workload)
    if shift_match:
        return to_number(shift_match.group(1), default=1.0)

    shifts_match = re.search(r"/\s*([0-9.]+)\s*shifts", normalized_workload)
    if shifts_match:
        return to_number(shifts_match.group(1), default=1.0)

    if "line/shift" in normalized_workload or "/shift" in normalized_workload:
        return n_shift if n_shift > 0 else 1.0

    if "/machine" in normalized_workload or "/line" in normalized_workload:
        return n_shift if n_shift > 0 else 1.0

    return n_shift if n_shift > 0 else 1.0


def parse_machine_based_workload(
    workload: str,
    n_shift: float,
) -> tuple[float, float, float] | None:
    normalized_workload = clean_text(workload)

    if normalized_workload in CUSTOM_WORKLOAD_KEYWORDS:
        return None

    if normalized_workload == "":
        return None

    quantity_match = re.match(r"^\s*([0-9.]+)", normalized_workload)
    if quantity_match is None:
        return None

    quantity = to_number(quantity_match.group(1), default=0.0)
    if quantity == 0.0 and "not required" in normalized_workload.lower():
        shift_multiplier = n_shift if n_shift > 0 else 1.0
        return 0.0, 1.0, shift_multiplier

    divisor_match = re.search(r"/\s*([0-9.]+)\s*machine", normalized_workload.lower())
    divisor = to_number(divisor_match.group(1), default=1.0) if divisor_match else 1.0

    shift_multiplier = determine_shift_multiplier(normalized_workload, n_shift)
    return quantity, divisor, shift_multiplier


def build_formula_text(
    machine_count_for_formula: float,
    quantity: float,
    divisor: float,
    shift_multiplier: float,
) -> str:
    machine_text = format_formula_number(machine_count_for_formula)
    quantity_text = format_formula_number(quantity)
    divisor_text = format_formula_number(divisor)
    shift_text = format_formula_number(shift_multiplier)

    if quantity == 0.0:
        return f"({machine_text}*0)*{shift_text}"

    if divisor == 1.0:
        return f"({machine_text}*{quantity_text})*{shift_text}"

    if quantity == 1.0:
        return f"({machine_text}/{divisor_text})*{shift_text}"

    return f"(({machine_text}*{quantity_text})/{divisor_text})*{shift_text}"


def parse_formula_template(formula_text: str) -> tuple[float, float, float] | None:
    normalized_formula = clean_text(formula_text).replace(" ", "")

    multiply_pattern = re.fullmatch(r"\(([-0-9.]+)\*([-0-9.]+)\)\*([-0-9.]+)", normalized_formula)
    if multiply_pattern:
        return (
            to_number(multiply_pattern.group(2), default=0.0),
            1.0,
            to_number(multiply_pattern.group(3), default=1.0),
        )

    divide_pattern = re.fullmatch(r"\(([-0-9.]+)/([-0-9.]+)\)\*([-0-9.]+)", normalized_formula)
    if divide_pattern:
        return (
            1.0,
            to_number(divide_pattern.group(2), default=1.0),
            to_number(divide_pattern.group(3), default=1.0),
        )

    nested_pattern = re.fullmatch(r"\(\(([-0-9.]+)\*([-0-9.]+)\)/([-0-9.]+)\)\*([-0-9.]+)", normalized_formula)
    if nested_pattern:
        return (
            to_number(nested_pattern.group(2), default=0.0),
            to_number(nested_pattern.group(3), default=1.0),
            to_number(nested_pattern.group(4), default=1.0),
        )

    return None


def is_close_enough(reference_value: float, candidate_value: float) -> bool:
    tolerance = max(0.25, abs(reference_value) * 0.15)
    return abs(reference_value - candidate_value) <= tolerance


def update_row_from_machine_count(
    master_table: pd.DataFrame,
    row_index: int,
    display_machine_count: float,
    formula_machine_count: float | None = None,
    force_formula_update: bool = False,
    allow_auto_formula_update: bool = True,
) -> None:
    current_machine_count = to_number(master_table.at[row_index, "Machine_Count"])
    current_scientific = to_number(master_table.at[row_index, "BE_Scientific_Manpower"])
    current_formula = clean_text(master_table.at[row_index, "Formulas"])

    display_machine_count = to_number(display_machine_count)
    formula_machine_count = display_machine_count if formula_machine_count is None else to_number(formula_machine_count)
    master_table.at[row_index, "Machine_Count"] = display_machine_count

    parsed_formula = parse_formula_template(current_formula)
    workload = clean_text(master_table.at[row_index, "Workload"])
    n_shift = to_number(master_table.at[row_index, "N_shift"], default=1.0)
    parsed_workload = parse_machine_based_workload(workload, n_shift)

    if force_formula_update and parsed_formula is not None:
        quantity, divisor, shift_multiplier = parsed_formula
        scientific_value = 0.0 if divisor == 0 else formula_machine_count * quantity / divisor * shift_multiplier
        master_table.at[row_index, "Formulas"] = build_formula_text(
            machine_count_for_formula=formula_machine_count,
            quantity=quantity,
            divisor=divisor,
            shift_multiplier=shift_multiplier,
        )
        master_table.at[row_index, "BE_Scientific_Manpower"] = scientific_value
        return

    if force_formula_update and parsed_workload is not None:
        quantity, divisor, shift_multiplier = parsed_workload
        scientific_value = 0.0 if divisor == 0 else formula_machine_count * quantity / divisor * shift_multiplier
        master_table.at[row_index, "Formulas"] = build_formula_text(
            machine_count_for_formula=formula_machine_count,
            quantity=quantity,
            divisor=divisor,
            shift_multiplier=shift_multiplier,
        )
        master_table.at[row_index, "BE_Scientific_Manpower"] = scientific_value
        return

    if allow_auto_formula_update and parsed_formula is not None and current_machine_count > 0:
        quantity, divisor, shift_multiplier = parsed_formula
        expected_scientific = 0.0 if divisor == 0 else current_machine_count * quantity / divisor * shift_multiplier
        if is_close_enough(current_scientific, expected_scientific):
            scientific_value = 0.0 if divisor == 0 else formula_machine_count * quantity / divisor * shift_multiplier
            master_table.at[row_index, "Formulas"] = build_formula_text(
                machine_count_for_formula=formula_machine_count,
                quantity=quantity,
                divisor=divisor,
                shift_multiplier=shift_multiplier,
            )
            master_table.at[row_index, "BE_Scientific_Manpower"] = scientific_value
            return

    if allow_auto_formula_update and parsed_workload is not None and current_machine_count > 0:
        quantity, divisor, shift_multiplier = parsed_workload
        expected_scientific = 0.0 if divisor == 0 else current_machine_count * quantity / divisor * shift_multiplier
        if is_close_enough(current_scientific, expected_scientific):
            scientific_value = 0.0 if divisor == 0 else formula_machine_count * quantity / divisor * shift_multiplier
            master_table.at[row_index, "Formulas"] = build_formula_text(
                machine_count_for_formula=formula_machine_count,
                quantity=quantity,
                divisor=divisor,
                shift_multiplier=shift_multiplier,
            )
            master_table.at[row_index, "BE_Scientific_Manpower"] = scientific_value
            return

    ratio = to_number(master_table.at[row_index, "_scientific_ratio"])
    master_table.at[row_index, "BE_Scientific_Manpower"] = display_machine_count * ratio


def apply_linked_machine_count(
    master_table: pd.DataFrame,
    section: str,
    dept_machine_name: str,
    designation: str,
    machine_count: float,
    formula_machine_count: float | None = None,
) -> None:
    mask = build_row_mask(master_table, section, dept_machine_name, designation)
    if not mask.any():
        return

    row_index = master_table[mask].index[0]
    if bool(master_table.at[row_index, "_machine_count_overridden"]):
        return

    update_row_from_machine_count(
        master_table=master_table,
        row_index=row_index,
        display_machine_count=machine_count,
        formula_machine_count=formula_machine_count,
        force_formula_update=formula_machine_count is not None,
        allow_auto_formula_update=False,
    )


def distribute_shifts(
    final_value: float,
    n_shift: float,
    general_shift: float,
) -> tuple[float, float, float, float]:
    if n_shift <= 1:
        return general_shift, 0.0, 0.0, 0.0

    remaining = max(final_value - general_shift, 0.0)
    shift_a = int(remaining // 3)
    shift_b = int(remaining // 3)
    shift_c = round_half_up(remaining - shift_a - shift_b, 0)
    return general_shift, shift_a, shift_b, shift_c


def sync_final_from_scientific(master_table: pd.DataFrame, sections_to_sync: list[str]) -> None:
    section_candidates: set[str] = set()
    for section_name in sections_to_sync:
        section_candidates.update(get_section_candidates(section_name))

    mask = master_table["Section"].isin(section_candidates)

    for row_index in master_table[mask].index:
        scientific = to_number(master_table.at[row_index, "BE_Scientific_Manpower"])
        designation = clean_text(master_table.at[row_index, "Designation"])
        section = clean_text(master_table.at[row_index, "Section"])

        if section == "Coating" and designation in COATING_SPECIAL_DESIGNATIONS:
            final_value = float(math.ceil(scientific))
        else:
            final_value = round_half_up(scientific, 0)

        master_table.at[row_index, "BE_Final_Manpower"] = final_value

        general_shift = to_number(master_table.at[row_index, "General_Shift"])
        n_shift = to_number(master_table.at[row_index, "N_shift"])

        if general_shift == 0:
            general_shift, shift_a, shift_b, shift_c = distribute_shifts(
                final_value,
                n_shift,
                general_shift,
            )
            master_table.at[row_index, "General_Shift"] = general_shift
            master_table.at[row_index, "Shift_A"] = shift_a
            master_table.at[row_index, "Shift_B"] = shift_b
            master_table.at[row_index, "Shift_C"] = shift_c


def update_packing_tqm_rows(master_table: pd.DataFrame, helper_table: pd.DataFrame) -> None:
    smart_lines = float(helper_table.loc[helper_table["Line"] == "Smart Line", "Reqd. Lines"].iloc[0])
    ina_lines = float(helper_table.loc[helper_table["Line"] == "INA", "Reqd. Lines"].iloc[0])
    chenille_lines = float(helper_table.loc[helper_table["Line"] == "Manual (Chenille)", "Reqd. Lines"].iloc[0])
    cotton_lines = float(helper_table.loc[helper_table["Line"] == "Manual (Cotton)", "Reqd. Lines"].iloc[0])

    mapping = {
        ("Packing  Line MP", "Smart Line"): smart_lines,
        ("Packing  Line MP", "INA"): ina_lines,
        ("Packing  Line MP", "Manual (Chenille)"): chenille_lines,
        ("Packing  Line MP", "Manual (Cotton)"): cotton_lines,
    }

    for (section, dept_machine_name), machine_count in mapping.items():
        mask = master_table["Section"].isin(get_section_candidates(section)) & (
            master_table["Dept_Machine_Name"] == dept_machine_name
        )
        for row_index in master_table[mask].index:
            update_row_from_machine_count(master_table, row_index, machine_count)
            master_table.at[row_index, "BE_Final_Manpower"] = round_half_up(
                to_number(master_table.at[row_index, "BE_Scientific_Manpower"]),
                0,
            )

    total_lines = smart_lines + ina_lines + chenille_lines + cotton_lines
    chenille_req_day = float(helper_table.loc[helper_table["Line"] == "Manual (Chenille)", "Req/Day"].iloc[0])
    drylon_tqm = float(helper_table.loc[helper_table["Line"] == "Smart Line", "TQM"].iloc[0])
    chenille_tqm = float(helper_table.loc[helper_table["Line"] == "Manual (Chenille)", "TQM"].iloc[0])
    cotton_tqm = float(helper_table.loc[helper_table["Line"] == "Manual (Cotton)", "TQM"].iloc[0])

    custom_scientific = {
        ("Packing Support MP", "Packing Support", "IMS"): total_lines * 3,
        ("Packing Support MP", "Packing Support", "Line Jobber"): total_lines * 3,
        ("Packing Support MP", "Packing Support", "Rework (Stain/Coating)"): round_half_up(total_lines / 2, 0) * 3,
        ("Packing Support MP", "Packing Support", "Mender"): round_half_up(total_lines / 2, 0) * 3,
        ("Packing Support MP", "Packing Support", "Carton Pkg"): total_lines * 9,
        ("Packing Support MP", "Packing Support", "Carton Pkg jobber"): round_half_up(total_lines / 2, 0) * 3,
        ("Packing Support MP", "Packing Support", "Chenille Preparation (Only Sewing Line)"): chenille_req_day / 600,
        ("TQM", "Drylon TQM", "TQM Per Day"): round_half_up(drylon_tqm * (smart_lines + ina_lines), 0) * 3,
        ("TQM", "Chenille TQM", "TQM Per Day"): round_half_up(chenille_tqm * chenille_lines, 0) * 3,
        ("TQM", "Cotton TQM", "TQM Per Day"): round_half_up(cotton_tqm * cotton_lines, 0) * 3,
    }

    for (section, dept_machine_name, designation), scientific_value in custom_scientific.items():
        mask = build_row_mask(master_table, section, dept_machine_name, designation)
        if mask.any():
            row_index = master_table[mask].index[0]
            master_table.at[row_index, "BE_Scientific_Manpower"] = scientific_value
            master_table.at[row_index, "BE_Final_Manpower"] = round_half_up(scientific_value, 0)


def apply_manual_master_edits(
    master_table: pd.DataFrame,
    edited_section_df: pd.DataFrame,
    original_section_df: pd.DataFrame,
) -> pd.DataFrame:
    updated_table = master_table.copy()

    for row_position, row_index in enumerate(original_section_df.index.tolist()):
        original_row = original_section_df.iloc[row_position]
        edited_row = edited_section_df.iloc[row_position]

        new_machine_count = to_number(edited_row["Machine_Count"])
        old_machine_count = to_number(original_row["Machine_Count"])

        if abs(new_machine_count - old_machine_count) > 1e-9:
            updated_table.at[row_index, "_machine_count_overridden"] = True
            section_name = clean_text(original_row["Section"])
            designation = clean_text(original_row["Designation"])
            update_row_from_machine_count(
                updated_table,
                row_index,
                new_machine_count,
                formula_machine_count=new_machine_count,
                force_formula_update=True,
            )

        for column_name in [
            "Operator_Type",
            "Contractors",
            "Company_Associate",
            "BE_Final_Manpower",
            "General_Shift",
            "Shift_A",
            "Shift_B",
            "Shift_C",
            "Reliever",
            "Remarks",
        ]:
            updated_table.at[row_index, column_name] = edited_row[column_name]

    return updated_table


def recalculate_master_table(
    master_source_table: pd.DataFrame,
    live_master_table: pd.DataFrame | None,
    coating_table: pd.DataFrame,
    cs_table: pd.DataFrame,
    hydro_table: pd.DataFrame,
    dyeing_result: dict[str, object],
    packing_tqm_helper: pd.DataFrame,
    manual_machine_count_overrides: dict | None = None,
) -> pd.DataFrame:
    master_table = prepare_master_table(master_source_table)
    master_table = clone_master_with_user_edits(master_table, live_master_table)

    coating_total = float(
        coating_table[
            (coating_table["Parameter"] == "Machines Required")
            & (coating_table["Material"] == "Total")
        ]["Value"].iloc[0]
    )
    coating_drylon = float(
        coating_table[
            (coating_table["Parameter"] == "Machines Required")
            & (coating_table["Material"] == "Drylon")
        ]["Value"].iloc[0]
    )

    apply_linked_machine_count(
        master_table,
        "Coating",
        "Latex Coating",
        "OPERATOR (MONORAIL-ROLL RECEIVING, ROLL STORAGE & SHIFTING)",
        coating_total,
        formula_machine_count=coating_total,
    )
    apply_linked_machine_count(
        master_table,
        "Coating",
        "Latex Coating",
        "OPERATOR (RE-ROLLING)",
        0.0,
        formula_machine_count=0.0,
    )

    for designation in COATING_SPECIAL_DESIGNATIONS:
        apply_linked_machine_count(
            master_table,
            "Coating",
            "Latex Coating",
            designation,
            coating_drylon,
            formula_machine_count=coating_total,
        )

    for designation in [
        "OPERATOR (ROLL WINDING, STAKING)",
        "JOBBER (PRE COAT, MAIN COAT)",
        "MATERIAL HANDLER (CLEANING & WASTAGE DISPOSEL)",
        "DATA OPERATOR / MONITOR",
        "OPERATOR (PCS RECOVERY)",
    ]:
        apply_linked_machine_count(
            master_table,
            "Coating",
            "Latex Coating",
            designation,
            coating_total,
            formula_machine_count=coating_total,
        )

    apply_linked_machine_count(
        master_table,
        "Coating",
        "Latex Compaunding",
        "OPERATOR (RAW MATERIAL LOADING AND MIXING)",
        coating_total,
        formula_machine_count=coating_total,
    )

    def cs_value(process: str, metric: str) -> float:
        row = cs_table[
            (cs_table["Section"] == "Machine")
            & (cs_table["Process"] == process)
            & (cs_table["Metric"] == metric)
        ]
        if row.empty:
            return 0.0
        return to_number(row.iloc[0]["Value"])

    length_cutting_total = round(cs_value("Length Cutting M/C", "Total M/C Reqd"))
    cross_cutting_total = round(cs_value("Cross cutting M/C", "Total M/C Reqd"))
    shape_cutting_total = round(cs_value("Shape cutting M/C", "Total M/C Reqd"))
    manual_cutting_total = round(cs_value("Printed / Manual cutting", "Total M/C Reqd"))
    tape_binding_total = round(cs_value("Tape Binding", "Total M/C Reqd"))
    bartack_total = round(cs_value("Bartack", "Total M/C Reqd"))
    over_edging_total = round(cs_value("Over edging for Rugs", "Total M/C Reqd"))

    apply_linked_machine_count(master_table, "Cut & Sew", "Length Cutting", "Operator", length_cutting_total)
    apply_linked_machine_count(master_table, "Cut & Sew", "Length Cutting", "Operator (Roll Feeder / Roll to Roll stitching)", length_cutting_total)
    apply_linked_machine_count(master_table, "Cut & Sew", "Length Cutting", "Material Handler", length_cutting_total)
    apply_linked_machine_count(master_table, "Cut & Sew", "Length Over edging", "Operator", cross_cutting_total)
    apply_linked_machine_count(master_table, "Cut & Sew", "Automaic Shape Cutting m/c", "Cutter Operator", shape_cutting_total)
    apply_linked_machine_count(master_table, "Cut & Sew", "Automaic Shape Cutting m/c", "Spreader Operator /layering", shape_cutting_total)
    apply_linked_machine_count(master_table, "Cut & Sew", "Automaic Shape Cutting m/c", "Material Handler", shape_cutting_total)
    apply_linked_machine_count(master_table, "Cut & Sew", "Cross Cutting", "Operator", cross_cutting_total)
    apply_linked_machine_count(master_table, "Cut & Sew", "Manual Cutting", "(750 Pcs Per Person output considered)", manual_cutting_total)
    apply_linked_machine_count(master_table, "Cut & Sew", "Stitching m/c", "Union - Stitcher + Tape Binding", tape_binding_total)
    apply_linked_machine_count(master_table, "Cut & Sew", "Stitching m/c", "Bartack  - Stitcher (Tape Binding + Over Edgimg)", bartack_total)
    apply_linked_machine_count(master_table, "Cut & Sew", "Stitching m/c", "Titan - Stitcher", over_edging_total)

    apply_linked_machine_count(master_table, "Dyeing", "Paddle", "Operator", float(dyeing_result["paddle_count"]))
    apply_linked_machine_count(master_table, "Dyeing", "EZM", "Operator", float(dyeing_result["ezm_count"]))
    apply_linked_machine_count(master_table, "Dyeing", "Jet Dyeing", "Operator", float(dyeing_result["jet_count"]))
    apply_linked_machine_count(master_table, "Dyeing", "Hydro", "Operator", to_number(hydro_table.at[0, "Total M/c Req"]))

    update_packing_tqm_rows(master_table, packing_tqm_helper)

    linked_sections = ["Coating", "Cut & Sew", "Dyeing"] + PACKING_TQM_SECTIONS
    sync_final_from_scientific(master_table, linked_sections)

    master_table["Section"] = pd.Categorical(
        master_table["Section"],
        categories=list(dict.fromkeys(master_table["Section"].tolist())),
        ordered=True,
    )
    master_table = master_table.sort_values("_business_order").reset_index(drop=True)
    return master_table
