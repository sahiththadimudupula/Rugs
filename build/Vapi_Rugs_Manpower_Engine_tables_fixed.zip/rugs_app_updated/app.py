from __future__ import annotations

from main import render_app


if __name__ == "__main__":
    render_app()
