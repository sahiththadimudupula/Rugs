from __future__ import annotations

from io import BytesIO
from pathlib import Path

import pandas as pd

from calculations.packing_tqm import split_packing_tqm_tables
from config.constants import MASTER_COLUMNS
from core.paths import get_active_workbook_path, get_input_workbook_path, get_working_workbook_path


PACKING_TQM_SHEET_NAME = "Packing&TQM"
HYDRO_SHEET_NAME = "Hydro "


def load_workbook_tables() -> dict[str, pd.DataFrame]:
    workbook_path = get_active_workbook_path()
    if not workbook_path.exists():
        raise FileNotFoundError(
            f"Workbook not found. Please place the file at: {get_input_workbook_path()}"
        )

    packing_tqm_raw_df = pd.read_excel(workbook_path, sheet_name=PACKING_TQM_SHEET_NAME, header=None)
    packing_tqm_source_df, packing_tqm_draft_df = split_packing_tqm_tables(packing_tqm_raw_df)

    return {
        "master_source_df": pd.read_excel(workbook_path, sheet_name="Rugs"),
        "packing_source_df": pd.read_excel(workbook_path, sheet_name="Packing"),
        "capacity_source_df": pd.read_excel(workbook_path, sheet_name="Capacity"),
        "coating_source_df": pd.read_excel(workbook_path, sheet_name="Coating"),
        "cs_source_df": pd.read_excel(workbook_path, sheet_name="CS"),
        "hydro_source_df": pd.read_excel(workbook_path, sheet_name=HYDRO_SHEET_NAME),
        "dye_mc_source_df": pd.read_excel(workbook_path, sheet_name="Dye_Mc"),
        "packing_tqm_raw_df": packing_tqm_raw_df,
        "packing_tqm_source_df": packing_tqm_source_df,
        "packing_tqm_draft_source_df": packing_tqm_draft_df,
    }


def _write_packing_tqm_sheet(writer: pd.ExcelWriter, state: dict) -> None:
    helper_df = state["packing_tqm_helper_df"].copy()
    draft_df = state["master_df"][state["master_df"]["Section"].isin([
        "Packing  Line MP",
        "Packing Support MP",
        "TQM",
        "TQM Other Support",
    ])].copy()

    helper_df.to_excel(writer, sheet_name=PACKING_TQM_SHEET_NAME, index=False, startrow=1)
    draft_df[MASTER_COLUMNS].to_excel(
        writer,
        sheet_name=PACKING_TQM_SHEET_NAME,
        index=False,
        startrow=len(helper_df) + 5,
    )


def _write_state_to_excel(writer: pd.ExcelWriter, state: dict) -> None:
    state["master_df"][MASTER_COLUMNS].to_excel(writer, sheet_name="Rugs", index=False)
    state["asking_rate_df"].drop(
        columns=[column for column in state["asking_rate_df"].columns if column in {"row_type", "display_order"}],
        errors="ignore",
    ).to_excel(writer, sheet_name="Packing", index=False)
    state["capacity_df"].to_excel(writer, sheet_name="Capacity", index=False)
    state["coating_df"].to_excel(writer, sheet_name="Coating", index=False)
    state["cs_df"].to_excel(writer, sheet_name="CS", index=False)
    state["hydro_df"].to_excel(writer, sheet_name=HYDRO_SHEET_NAME, index=False)
    state["dyeing_result"]["summary_df"].to_excel(writer, sheet_name="Dye_Mc", index=False)
    _write_packing_tqm_sheet(writer, state)


def save_workbook_tables(state: dict) -> Path:
    working_path = get_working_workbook_path()
    working_path.parent.mkdir(parents=True, exist_ok=True)

    with pd.ExcelWriter(working_path, engine="openpyxl") as writer:
        _write_state_to_excel(writer, state)

    return working_path


def export_workbook_bytes(state: dict) -> bytes:
    buffer = BytesIO()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        _write_state_to_excel(writer, state)
    buffer.seek(0)
    return buffer.getvalue()


def reset_working_workbook() -> None:
    working_path = get_working_workbook_path()
    if working_path.exists():
        working_path.unlink()
