from __future__ import annotations

from typing import Iterable

import pandas as pd

from core.formatting import clean_text, to_number


TOTAL_LABEL = "Total"
FORMULA_TOOLTIP_COLUMN = "_tooltip_formula"


def normalize_dataframe_for_compare(dataframe: pd.DataFrame) -> pd.DataFrame:
    normalized = dataframe.copy()
    normalized = normalized.reset_index(drop=True)
    for column_name in normalized.columns:
        if pd.api.types.is_numeric_dtype(normalized[column_name]):
            normalized[column_name] = normalized[column_name].fillna(0.0)
        else:
            normalized[column_name] = normalized[column_name].fillna("").astype(str)
    return normalized


def dataframes_different(left_df: pd.DataFrame | None, right_df: pd.DataFrame | None) -> bool:
    if left_df is None and right_df is None:
        return False
    if left_df is None or right_df is None:
        return True
    return not normalize_dataframe_for_compare(left_df).equals(normalize_dataframe_for_compare(right_df))


def get_numeric_columns(dataframe: pd.DataFrame, exclude_columns: Iterable[str] | None = None) -> list[str]:
    excluded = set(exclude_columns or [])
    numeric_columns: list[str] = []
    for column_name in dataframe.columns:
        if column_name in excluded:
            continue
        if pd.api.types.is_numeric_dtype(dataframe[column_name]):
            numeric_columns.append(column_name)
            continue
        if dataframe[column_name].dropna().empty:
            continue
        converted_series = pd.to_numeric(dataframe[column_name], errors="coerce")
        if converted_series.notna().any() and converted_series.notna().sum() == dataframe[column_name].replace("", pd.NA).dropna().shape[0]:
            numeric_columns.append(column_name)
    return numeric_columns


def build_total_row(
    dataframe: pd.DataFrame,
    label_column: str | None = None,
    label_value: str = TOTAL_LABEL,
    exclude_sum_columns: Iterable[str] | None = None,
) -> pd.Series:
    total_row = pd.Series({column_name: "" for column_name in dataframe.columns}, index=dataframe.columns, dtype=object)
    numeric_columns = get_numeric_columns(dataframe, exclude_columns=exclude_sum_columns)
    for column_name in numeric_columns:
        total_row[column_name] = pd.to_numeric(dataframe[column_name], errors="coerce").fillna(0.0).sum()

    if label_column and label_column in dataframe.columns:
        total_row[label_column] = label_value
    elif dataframe.columns.any():
        total_row[dataframe.columns[0]] = label_value

    return total_row


def append_total_row(
    dataframe: pd.DataFrame,
    label_column: str | None = None,
    label_value: str = TOTAL_LABEL,
    exclude_sum_columns: Iterable[str] | None = None,
) -> pd.DataFrame:
    if dataframe.empty:
        empty_with_total = dataframe.copy()
        if dataframe.columns.any():
            empty_with_total = pd.concat([empty_with_total, build_total_row(dataframe, label_column, label_value, exclude_sum_columns).to_frame().T], ignore_index=True)
        return empty_with_total

    total_row = build_total_row(
        dataframe=dataframe,
        label_column=label_column,
        label_value=label_value,
        exclude_sum_columns=exclude_sum_columns,
    )
    return pd.concat([dataframe, total_row.to_frame().T], ignore_index=True)


def extract_formula_tooltips(
    dataframe: pd.DataFrame,
    formula_column: str = "Formulas",
) -> pd.DataFrame:
    tooltip_df = pd.DataFrame("", index=dataframe.index, columns=dataframe.columns)
    if formula_column not in dataframe.columns:
        return tooltip_df

    formula_series = dataframe[formula_column].apply(clean_text)
    for row_index in dataframe.index:
        formula_text = formula_series.loc[row_index]
        if formula_text == "":
            continue
        for column_name in dataframe.columns:
            if column_name == formula_column:
                continue
            if pd.api.types.is_numeric_dtype(dataframe[column_name]) or pd.to_numeric(pd.Series([dataframe.at[row_index, column_name]]), errors="coerce").notna().iloc[0]:
                tooltip_df.at[row_index, column_name] = formula_text
    return tooltip_df


def coerce_numeric_columns(dataframe: pd.DataFrame, columns: Iterable[str]) -> pd.DataFrame:
    coerced_df = dataframe.copy()
    for column_name in columns:
        if column_name in coerced_df.columns:
            coerced_df[column_name] = coerced_df[column_name].apply(to_number)
    return coerced_df
